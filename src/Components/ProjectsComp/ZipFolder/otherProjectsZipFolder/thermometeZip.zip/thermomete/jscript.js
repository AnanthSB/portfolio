{/* <span id="temp" class="fa"></span> */ }

let spanId = document.getElementById('temp');
temp()
function temp() {
    let uc0 = '&#xf2cb';
    let uc1 = '&#xf2ca';
    let uc2 = '&#xf2c9';
    let uc3 = '&#xf2c8';
    let uc4 = '&#xf2c7';

    setTimeout( ()=>{
        spanId.innerHTML = uc0;
        spanId.style.color = '#ff00004d';
    }, 0000)
    setTimeout(() => {
        spanId.innerHTML = uc1;
        spanId.style.color = '#ff00004d';
    }, 1000);
    setTimeout(()=>{
        spanId.innerHTML = uc2;
        spanId.style.color = '#ff000063';
    },2000);
    setTimeout(()=>{
        spanId.innerHTML = uc3;
        spanId.style.color = '#ff000094';
    },3000);
    setTimeout(()=>{
        spanId.innerHTML = uc4;
        spanId.style.color = '#ff0000e8';
    },4000)
}
setInterval(temp, 5000)