//incomplete project


{/* <div id="joke" class="joke">Awesome joke is Loading...</div> */ }
{/* <button id="jokeBtn" class="btn">Next JOke</button> */ }

// Get https://icanhazdadjoke.com/
const jokes = document.querySelector('#joke');
const jokeBtn = document.querySelector('#jokeBtn');

const genrerateJokes = () => {
    const setHeader = {
        header: {
            Accept: "application/json"
        }
    }
    // fetch('https://icanhazdadjoke.com/', setHeader)
    fetch('https://v2.jokeapi.dev/joke/Any?blacklistFlags=nsfw,religious,political,racist,sexist,explicit&type=single', setHeader)
        .then((res) => res.json())
        .then((data) => {
            jokes.innerHTML = data.joke;
        }).catch((error) => {
            console.log(error)
        });

}

jokeBtn.addEventListener('click', genrerateJokes);
genrerateJokes();
