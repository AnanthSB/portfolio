let clicks = true;
function funcOn(){
    if(clicks){
        let bulbOn = '/mediaFiles/pic_bulbon.gif';
        $('#bulb').attr('src', bulbOn);
        $('.btnBulbOn').css({'background-color':'chartreuse'});
        $('.btnBulbOff').css({'background-color':'#ff00003b'})
        $('body').css({'background-color':'#000000b0'});
        clicks = false;
    }
}
function funcOff(){
    if(clicks == false){
        let bulbOff = '/mediaFiles/pic_bulboff.gif'
        $('#bulb').attr('src', bulbOff);
        $('.btnBulbOn').css({'background-color':'#7fff002e'});
        $('.btnBulbOff').css({'background-color':'rgb(255, 0, 0)'})
        $('body').css({'background-color':'#000000d4'});
        clicks = true;
    }
}