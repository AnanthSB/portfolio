---------------- 'Monthly Expenses' ----------------


This project is created by pure HTML, CSS and Javascript.
This is a responsive website built by me(Ananth Shetty) from 09-SEP-2021 to 30-SEP-2021. Which works well in mobile,
tabs, laptop or computer.

This project will help the user in managing his/her expenses every day, every month and every year how
much he/she is spending and he/she can keep track of their expenses and can manage accordingly.

This website/project contains a single page application, where the user can add expenses and can check them by 
sorting with monthly just by selecting the options given at right top nav icon.
User can delete the added expense if they wish to delete from the data/list of items just by clicking the delete
 button.

Currenlty this front end project is based on Web API's localStorage created, if user wish then user can connect to data base 
as per their choice of hosting, server.