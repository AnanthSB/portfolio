# Student-Library-
This is a Student Library project.

This library has two pages, one for login and one for main page where student can add, or delete a book from library.

The login page provides default login userid and password, by using them student can login and access the library.
The login page will allow only when entered login details are correct, otherwise it will through an error saying incorrect credentials.

The main page contains Borrow, Return, Add  and Delete a book options and logout button with a good visual format, also has a good format for 
  displaying the books added into library.
The added books will be stored into the browser localStorage, and will be erased as per the user book delete request.


In this project i used HTML, CSS and javascript and Jquery.